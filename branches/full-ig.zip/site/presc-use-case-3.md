Proposal order
In this case, the pharmacist proposes the medication to be ordered

<div>{% include presc-use-case-2.svg %}</div>
<br clear="all"/>
