
<figure>
  {% include dm-prescription-sl.svg %}
</figure>
<br clear="all"/>

<figure>
  {% include dm-prescription-ml.svg %}
</figure>
<br clear="all"/>

<figure>
  {% include dm-dispense.svg %}
</figure>
<br clear="all"/>
