# practitioner1 - Medication Prescription and Dispense (MPD) v1.0.0-comment-3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **practitioner1**

## Example Practitioner: practitioner1

Meryl Ärztin (hpc-265)

-------



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "practitioner1",
  "identifier" : [{
    "value" : "hpc-265"
  }],
  "name" : [{
    "family" : "Ärztin",
    "given" : ["Meryl"]
  }]
}

```
