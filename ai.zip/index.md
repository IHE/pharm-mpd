# IHE MPD (Medication Prescription and Dispense) - Medication Prescription and Dispense (MPD) v1.0.0-comment-3

* [**Table of Contents**](toc.md)
* **IHE MPD (Medication Prescription and Dispense)**

## IHE MPD (Medication Prescription and Dispense)

| | |
| :--- | :--- |
| *Official URL*:https://profiles.ihe.net/PHARM/MPD/ImplementationGuide/ihe.pharm.mpd | *Version*:1.0.0-comment-3 |
| Active as of 2025-05-08 | *Computable Name*:IHE_PHARM_MPD |
| **Copyright/Legal**: IHE http://www.ihe.net/Governance/#Intellectual_Property | |

The IHE MPD profile defines global data exchange specifications for medication prescription and dispense, in different settings and compatible with different workflows and jurisdictions.

The main goals of this Profile are:

* Support implementers of Pharmacy systems - simple or complex, local, national or cross-border.
* Provide common specifications for systems implementing or migrating to FHIR from previous standards, like HL7 v2 or HL7 CDA.
* Support vendors of software in allowing their software to support all the use cases involving Medication Prescription and Dispense while retaining a simple, modular interoperability framework that is less costly to implement and maintain.

## Overview

The MPD Profile describes

* actors and transactions for creating, updating, searching and reading prescriptions and any other types of medication orders;
* actors and transactions for creating, updating, searching and dispense reports, as well as consulting them;
* core concepts that are impactful to these specifications or to their use

## Organization of This Guide

### Volume 1: Use Cases and Standards

This section delves into functional aspects, detailing various use cases, and standardizing them for a global perspective.

* **Prescriptions**: Types and content of prescriptions.
* **Order Grouping**: Grouping of orders with and without interdependencies.
* **Ordering Workflows**: Common workflow aspects for medication ordering, considering approval, review, etc. with allowances for jurisdiction-specific requirements.

### Volume 2: Transactions

This technical section focuses on the technical data exchange, defining each of the transactions - their triggers, expected results, and semantics.

### Volume 3: Content and Terminology

Volume 3 describes data structures and terminology supporting this specification.

* **Medication Resource Definition**: A common data structure to represent any medication.
* **Terminologies**: Common terminologies for he product and its attributes.

### Related work:

#### HL7 Europe and European specifications

The IHE MPD Work was initiated based on the existing IHE profiles and anticipating a FHIR implementation, but has been decisively supported by HL7 Europe, who has worked on [related specifications](http://hl7.eu/fhir/mpd), which are related to past and ongoing projects and specifications that may be relevant.:

#### HL7 Gemini

IHE MPD is a Gemini project. This means that while the specification is edited and hosted by IHE, it has gone through review with the interested parties (work groups) at HL7 international. A single balloting process is used - while this is hosted by IHE, HL7 members have participated in the discussions and are also invited to participate in the comment process.

#### IHE Pharmacy profiles:

##### CMPD

the [IHE Community Medication Prescription and Dispense](https://www.ihe.net/uploadedFiles/Documents/Pharmacy/IHE_Pharmacy_Suppl_CMPD.pdf) is a CDA-based specification of Prescription and Dispense documents. The current IHE MPD profile covers a superset of the functionalities in CMPD, to allow transitioning from CDA-based architeture to FHIR-based interoperability.

##### MMA

The [IHE Mobile Medication Administration](https://www.ihe.net/uploadedFiles/Documents/Pharmacy/IHE_Pharm_Suppl_MMA.pdf) supports the request and report of medication administrations. The Medication Administration is a specific type of medication order, and therefore is technically compatible with the current profile, but is further specified in the MMA profile.

-------

### Dependencies

This IG Contains the following dependencies on other IGs.



### Cross Version Analysis

### Global Profiles

*There are no Global profiles defined*

### Intellectual Property

This publication includes IP covered under the following statements.

* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* SNOMED Clinical Terms&reg; (SNOMED CT&reg;): [Bundle/200-multiitem-prescription-without-orchestration](Bundle-200-multiitem-prescription-without-orchestration.md), [IHEMedication](StructureDefinition-IHEMedication.md)... Show 16 more, [Medication/01A-Cefuroxime1500GenericExplicit](Medication-01A-Cefuroxime1500GenericExplicit.md), [Medication/01B-Cefuroxime1500GenericConcept](Medication-01B-Cefuroxime1500GenericConcept.md), [Medication/01C-Cefuroxime1500Branded](Medication-01C-Cefuroxime1500Branded.md), [Medication/01D-Cefuroxime750Branded](Medication-01D-Cefuroxime750Branded.md), [Medication/02A1-CanifugCremolumCreamItem](Medication-02A1-CanifugCremolumCreamItem.md), [Medication/02A2-CanifugCremolumPessaryItem](Medication-02A2-CanifugCremolumPessaryItem.md), [Medication/03B-VitaminBComplexBranded](Medication-03B-VitaminBComplexBranded.md), [Medication/04-FirmagonBranded](Medication-04-FirmagonBranded.md), [Medication/05A-Tilidin-Branded](Medication-05A-Tilidin-Branded.md), [MedicationRequest/10-prescription-cefuroxime-singleline](MedicationRequest-10-prescription-cefuroxime-singleline.md), [MedicationRequest/100-3-medication-prescription-request1](MedicationRequest-100-3-medication-prescription-request1.md), [MedicationRequest/100-3-medication-prescription-request2](MedicationRequest-100-3-medication-prescription-request2.md), [MedicationRequest/100-3-medication-prescription-request3](MedicationRequest-100-3-medication-prescription-request3.md), [MedicationStrengthSubstance](StructureDefinition-ihe-ext-medication-strengthsubstance.md), [PractitionerRole/doctor1](PractitionerRole-doctor1.md) and [PractitionerRole/pharmacist1](PractitionerRole-pharmacist1.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [Common Tags](http://terminology.hl7.org/7.2.0/CodeSystem-common-tags.html): [MedicationRequest/10-prescription-cefuroxime-singleline](MedicationRequest-10-prescription-cefuroxime-singleline.md)
* [MedicationKnowledge Characteristic Codes](http://terminology.hl7.org/7.2.0/CodeSystem-medicationknowledge-characteristic.html): [MedicationCharacteristic](StructureDefinition-ihe-ext-medication-characteristic.md)


* Unless otherwise indicated, reproduction of material posted on Council of Europe websites, and reproduction of photographs for which the Council of Europe holds copyright – see legal notice \“photo credits\” – is authorised for private use and for informational and educational uses relating to the Council of Europe’s work. This authorisation is subject to the condition that the source be indicated and no charge made for reproduction. Persons wishing to make some other use than those specified above, including commercial use, of information and text posted on these sites are asked to apply for prior written authorisation to the Council of Europe, Directorate of Communication.

* [EDQM Standard Terms](http://tx.fhir.org/r5/ValueSet/edqm): [Medication/01A-Cefuroxime1500GenericExplicit](Medication-01A-Cefuroxime1500GenericExplicit.md), [Medication/01C-Cefuroxime1500Branded](Medication-01C-Cefuroxime1500Branded.md)... Show 8 more, [Medication/01D-Cefuroxime750Branded](Medication-01D-Cefuroxime750Branded.md), [Medication/02A-ClotrimazoleCanifugCremolum](Medication-02A-ClotrimazoleCanifugCremolum.md), [Medication/02A1-CanifugCremolumCreamItem](Medication-02A1-CanifugCremolumCreamItem.md), [Medication/02A2-CanifugCremolumPessaryItem](Medication-02A2-CanifugCremolumPessaryItem.md), [Medication/03B-VitaminBComplexBranded](Medication-03B-VitaminBComplexBranded.md), [Medication/04-FirmagonBranded](Medication-04-FirmagonBranded.md), [Medication/05A-Tilidin-Branded](Medication-05A-Tilidin-Branded.md) and [MedicationRequest/10-prescription-cefuroxime-singleline](MedicationRequest-10-prescription-cefuroxime-singleline.md)


* WHO Collaborating Centre for Drug Statistics Methodology, Oslo, Norway. Use of all or parts of the material requires reference to the WHO Collaborating Centre for Drug Statistics Methodology. Copying and distribution for commercial purposes is not allowed. Changing or manipulating the material is not allowed.

* [ATC classification system](http://tx.fhir.org/r5/ValueSet/atc): [Medication/01A-Cefuroxime1500GenericExplicit](Medication-01A-Cefuroxime1500GenericExplicit.md), [Medication/01C-Cefuroxime1500Branded](Medication-01C-Cefuroxime1500Branded.md)... Show 5 more, [Medication/01D-Cefuroxime750Branded](Medication-01D-Cefuroxime750Branded.md), [Medication/02A-ClotrimazoleCanifugCremolum](Medication-02A-ClotrimazoleCanifugCremolum.md), [Medication/03B-VitaminBComplexBranded](Medication-03B-VitaminBComplexBranded.md), [Medication/04-FirmagonBranded](Medication-04-FirmagonBranded.md) and [MedicationClassification](StructureDefinition-ihe-ext-medication-classification.md)


