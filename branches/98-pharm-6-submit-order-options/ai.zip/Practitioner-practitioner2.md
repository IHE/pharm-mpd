# practitioner2 - Medication Prescription and Dispense (MPD) v1.0.0-comment-3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **practitioner2**

## Example Practitioner: practitioner2

Moon Farmatseut (hpc-pharm-124)

-------



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "practitioner2",
  "identifier" : [{
    "value" : "hpc-pharm-124"
  }],
  "name" : [{
    "family" : "Farmatseut",
    "given" : ["Moon"]
  }]
}

```
