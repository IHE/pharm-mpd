
<figure>
  {% include overall-model.svg %}
</figure>
<br clear="all"/>

