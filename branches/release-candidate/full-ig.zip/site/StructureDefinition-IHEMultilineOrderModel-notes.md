Detailed diagram:
<figure>
  {% include IHEMultilineOrderModel.svg %}
</figure>