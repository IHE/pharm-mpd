Detailed diagram:
<figure>
  {% include IHEMedicationOrderModel.svg %}
</figure>