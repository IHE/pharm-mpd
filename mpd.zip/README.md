Empty IG
---
This is the source for the IHE Pharmacy Medication Prescription and Delivery profile.
<br> </br>
###
### Publication
This ImplementationGuide is published in the following locations:

Continuous Build: __http://build.fhir.org/ig/IHE/pharm-mpd__  
Continuous Build: __http://ihe.github.io/pharm-mpd__  
Canonical / permanent URL: 
<br> </br>

### Issues
Issues and change requests are managed here:  

Issues:  __https://github.com/IHE/pharm-mpd/issues__  
Kanban board:  __https://github.com/IHE/pharm-mpd/projects/1__  

---
   
 
